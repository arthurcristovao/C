#include "Stack.h"

#define MAX 10
int stack[MAX];
int top = 0; // use 0 ou -1. Decida conforme voc� achar melhor!

bool push(int value)
{
	// implemente a inser��o.
	// se est� cheia, retorne o valor FALSE
	// se conseguiu inserir, retorne o valor TRUE
	
}

bool pop(int* value)
{
	// implemente a remo��o da pilha.
	// se est� vazia, retorne o valor FALSE
	// se conseguiu inserir, retorne o valor TRUE
	// value deve receber o valor no topo da pilha (aten��o passagem de par�metro por refer�ncia)
	
}

bool empty()
{
	//verifique se est� vazia
}

bool full()
{
	//verifique se est� cheia
}

