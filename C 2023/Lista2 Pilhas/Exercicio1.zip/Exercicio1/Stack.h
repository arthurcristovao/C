#include <stdbool.h>


bool push(int value);
bool pop(int* value);
bool empty();
bool full();

